package com.vishma_app_dev.news_app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import com.vishma_app_dev.news_app.ui.theme.News_AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            News_AppTheme {
                HomeScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val categories = listOf("business","entertainment","general","health","science","sports","technology")
    var selectedCategory by rememberSaveable { mutableStateOf(categories[0]) }
    val newsItems by remember { mutableStateOf(listOf<NewsItem>()) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("News App") },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(imageVector = Icons.Default.Home, contentDescription = "Menu")
                    }
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = { Text("Bookmarks") },
                icon = { Icon(imageVector = Icons.Filled.FavoriteBorder, contentDescription = "Bookmarks") },
                onClick = {}
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCategory),
                edgePadding = 8.dp
            ) {
                categories.forEach { category ->
                    Tab(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        text = { Text(category) }
                    )
                }
            }

            LazyColumn(modifier = Modifier.padding(8.dp)) {
                items(newsItems) {
                    x ->

                    NewsCard(newsItem = x)
                }
            }
        }
    }
}

data class NewsItem (
    val headline: String,
    val description: String,
    val imageUrl: String,
)

@Composable
fun NewsCard(
    newsItem: NewsItem,
    context: android.content.Context = LocalContext.current
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_foreground), // Placeholder image
                contentDescription = "News Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(newsItem.headline, style = MaterialTheme.typography.titleLarge)
            Text(newsItem.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row {
                IconButton(onClick = {}) { Icon(imageVector = Icons.Filled.FavoriteBorder, contentDescription = "Save") }
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    val newIntent = Intent().apply {
                        action = Intent.ACTION_SEND;
                        putExtra("promotionText", "SENT USING NEWS APP BY VP DAS")
                        putExtra("headline", newsItem.headline);
                        putExtra("description",newsItem.description);
                        type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(newIntent, null)
                    context.startActivity(shareIntent)
                }) { Icon(imageVector = Icons.Default.Share, contentDescription = "Share") }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewHomeScreen() {
    News_AppTheme {
        HomeScreen()
    }
}

// API KEY: 0f429d2ea7fe4a5eb7cef516ea2c4660
