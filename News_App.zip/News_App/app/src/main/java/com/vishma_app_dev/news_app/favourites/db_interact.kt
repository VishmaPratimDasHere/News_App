package com.vishma_app_dev.news_app.favourites

import androidx.room.ColumnInfo
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

@Entity(tableName="favourites")
data class FavNewsEntity(
    @ColumnInfo(name="url")
    var url: String,
    @PrimaryKey
    @ColumnInfo(name = "title")
    var title: String,
    @ColumnInfo(name = "authors")
    var authors: List<String>,
    var content: String?
)

class TypeConvertors {
    @TypeConverter
    fun listToString(list: List<String>):String{
        return list.joinToString(separator = ";")
    }

    @TypeConverter
    fun stringToList(str: String?): List<String> {
        return str?.split(";")?.map { it.trim() }?.filter { it.isNotBlank() } ?: emptyList()
    }
}

interface myDao {
    @Insert
    suspend fun insert(item : FavNewsEntity)

    @Delete
    suspend fun delete(item: FavNewsEntity)
}